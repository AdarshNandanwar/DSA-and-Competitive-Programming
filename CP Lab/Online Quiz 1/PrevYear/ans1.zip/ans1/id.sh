lines=`wc -l < Course_marks.txt`
cut -d ' ' -f 1 Course_marks.txt > i.txt
tr -s ' ' < performance.txt | cat > i2.txt
tr -s ' ' < Course_marks.txt | cat > i1.txt
for (( i=1 ; i<=$lines ; i++ ))
do
a=`head -n$i i.txt | tail -1`
b=`grep $a i2.txt | cut -c 15`
if [ $b='O' ]
then 
	c=`head -n$i i1.txt | tail -1`
	set $c
	echo " $1 `expr $2 + 10` " | cat >> Final.txt
	continue
elif [ $b='A' ]
then 
	c=`head -n$i i1.txt | tail -1`
	set $c
	echo " $1 `expr $2 + 5` " | cat >> Final.txt
	continue
elif [ $b='E' ]
then 
	c=`head -n$i i1.txt | tail -1`
	set $c
	echo " $1 `expr $2 + 2` " | cat >> Final.txt
	continue
fi
done


